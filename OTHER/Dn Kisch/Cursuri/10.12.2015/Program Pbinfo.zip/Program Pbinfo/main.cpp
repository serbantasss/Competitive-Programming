#include <iostream>
#include <cmath>
using namespace std;
int a[201][201],v[10];
int main()
{
    //ifstream cin("1.in");
    //ofstream cout("1.out");
    int n,i,j,k;
    cin>>n;
    k=n/2;
    if(n%2==0)
        k--;
    for(i=1;i<=k;++i)
        for(j=i+1;j<=n-i;++j)
            a[i][j]=1;
    for(i=n;i>n-k;--i)
        for(j=n-i+2;j<=n-i;++j)
            a[i][j]=2;
    for(j=1;j<=k;++j)
        for(i=j+1;i<=n-j;++i)
            a[i][j]=3;
    for(j=n;j>n-k;--j)
        for(i=n-j+2;i<=n-j;++i)
            a[i][j]=3;
    for(i=1;i<=n;++i)
    {
        for(j=1;j<=n;++j)
            cout<<a[i][j]<<" ";
        cout<<endl;
    }
    return 0;
}
